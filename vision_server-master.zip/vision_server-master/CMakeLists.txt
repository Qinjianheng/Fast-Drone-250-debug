cmake_minimum_required(VERSION 3.0.2)
project(vision_server)

set(CMAKE_CXX_STANDARD 14)
set(CMAKE_BUILD_TYPE "Release")
set(CMAKE_EXPORT_COMPILE_COMMANDS 1)

find_package(catkin REQUIRED COMPONENTS
  roscpp
  message_filters
  cv_bridge
  sensor_msgs
  nav_msgs
  message_generation
)

find_package(Eigen3 REQUIRED)
find_package(OpenCV REQUIRED)
find_package(Ceres REQUIRED)

add_service_files(
  FILES
  circle.srv
  cylinder.srv
  switch_mode.srv
)

generate_messages(
  DEPENDENCIES
  std_msgs
  #geometry_msgs
)

catkin_package(
  CATKIN_DEPENDS roscpp message_filters cv_bridge sensor_msgs nav_msgs message_runtime
)

include_directories(
  detector/include
  ${catkin_INCLUDE_DIRS}
  ${EIGEN3_INCLUDE_DIRS}
  ${OpenCV_INCLUDE_DIRS}
  ${CERES_INCLUDE_DIRS}
  ${PCL_INCLUDE_DIRS}
)

#圆环检测源代码
aux_source_directory(detector/circle CIRCLE_SRC)
#圆柱检测源代码
aux_source_directory(detector/cylinder CYLINDER_SRC)

add_library(detector ${CIRCLE_SRC} ${CYLINDER_SRC})
target_link_libraries(detector ${OpenCV_LIBRARIES} ${CERES_LIBRARIES})

add_executable(vision_server src/vision_server.cpp)
target_link_libraries(vision_server detector ${OpenCV_LIBRARIES} ${catkin_LIBRARIES})

add_executable(circle_test src/circle_test.cpp)
target_link_libraries(circle_test detector ${OpenCV_LIBRARIES} ${catkin_LIBRARIES})

add_executable(cylinder_test src/cylinder_test.cpp)
target_link_libraries(cylinder_test detector ${OpenCV_LIBRARIES} ${catkin_LIBRARIES})

