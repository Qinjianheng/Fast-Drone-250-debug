#include <ros/ros.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>

#include <cv_bridge/cv_bridge.h>

#include <sensor_msgs/Image.h>

#include <chrono>
#include "detector.hpp"

using namespace std;
using namespace cv;
using namespace Eigen;

class CircleTest
{
private:
    ros::NodeHandle& nh;
    message_filters::Subscriber<sensor_msgs::Image> color_sub;
    message_filters::Subscriber<sensor_msgs::Image> depth_sub;
    message_filters::TimeSynchronizer<sensor_msgs::Image, sensor_msgs::Image> color_depth_sync;

    shared_ptr<CircleFrontend> circle_frontend;
    shared_ptr<CircleBackend> circle_backend;

    const string circle_frontend_method;
    Matrix3d inner_m;
public:
    CircleTest(ros::NodeHandle& nh_, const FileStorage& fs): 
        nh(nh_), color_sub(nh, (string)fs["color_topic"], 1), depth_sub(nh, (string)fs["depth_topic"], 1), color_depth_sync(color_sub, depth_sub, 10), 
        circle_frontend_method((string)fs["circle_method"])
    {
        circle_frontend = make_shared<CircleFrontend>(fs);
        circle_backend = make_shared<CircleBackend>(fs);

        cv::Mat cam_inner_cvmat;
        fs["cam_inner"] >> cam_inner_cvmat;
        cv::cv2eigen(cam_inner_cvmat, inner_m);

        color_depth_sync.registerCallback(&CircleTest::color_depth_cb, this);
    }

private:
    void visualize(Mat& color_img, const CircleBackendResult_t& circle)
    {
        const Eigen::Vector3d vs = inner_m * circle.center;
        const Eigen::Vector3d end_point = circle.center - circle.direction;
        const Eigen::Vector3d v = inner_m * end_point;
        const Point2f sp(vs.x() / vs.z(), vs.y() / vs.z());
        const Point2f ep(v.x() / v.z(), v.y() / v.z());
        arrowedLine(color_img, sp, ep, Scalar(0, 0, 255), 3);

        //显示图像
        imshow("video", color_img);
        waitKey(1);
    }

    void color_depth_cb(const sensor_msgs::Image::ConstPtr& color_msg, const sensor_msgs::Image::ConstPtr& depth_msg)
    {
        auto color_img = cv_bridge::toCvCopy(color_msg, "bgr8");
        auto depth_img = cv_bridge::toCvShare(depth_msg, depth_msg->encoding);
        try{
            auto circle_begin = chrono::high_resolution_clock::now();
            CircleFrontendResult_t circle_frontend_result;
            if(circle_frontend_method == "shape")
                circle_frontend_result = circle_frontend->shape_frontend(color_img->image, depth_img->image);
            else
                circle_frontend_result = circle_frontend->simple_depth_frontend(color_img->image, depth_img->image);
            auto circle_backend_result = circle_backend->ceres_backend(circle_frontend_result);
            auto circle_end = chrono::high_resolution_clock::now();
            ROS_INFO("circle time cost: %.3fms", chrono::duration_cast<chrono::microseconds>(circle_end - circle_begin).count() * 1e-3);
            ROS_INFO("circle center: %.2f %.2f %.2f", circle_backend_result.center.x(), circle_backend_result.center.y(), circle_backend_result.center.z());
            ROS_INFO("circle direction: %.2f %.2f %.2f", circle_backend_result.direction.x(), circle_backend_result.direction.y(), circle_backend_result.direction.z());

            ROS_INFO("=========================");
            
            visualize(color_img->image, circle_backend_result);
        } catch(const char* e)
        {
            ROS_ERROR("%s", e);
            //显示图像
            imshow("video", color_img->image);
            waitKey(1);
        }
    }
};
 
int main(int argc, char **argv)
{
    ros::init(argc, argv, "circle_test");
    ros::NodeHandle nh;

    if(argc < 2)
        ROS_WARN("config file path not provided!\n" "usage: rosrun vision_server vision_server [config file]");

    const string config_path = argv[1];

    FileStorage fs(config_path, FileStorage::READ);
    CircleTest circle_test(nh, fs);
    ros::spin();
 
    return 0;
}