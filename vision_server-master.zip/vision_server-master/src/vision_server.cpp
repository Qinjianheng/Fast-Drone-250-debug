#include <ros/ros.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>

#include <cv_bridge/cv_bridge.h>

#include <sensor_msgs/Image.h>
#include <nav_msgs/Odometry.h>
#include <vision_server/circle.h>
#include <vision_server/cylinder.h>
#include <vision_server/switch_mode.h>

#include <chrono>
#include "detector.hpp"

using namespace std;
using namespace cv;
using namespace Eigen;

const Scalar colors[]{
    Scalar(255, 0, 0),
    Scalar(0, 255, 0),
    Scalar(0, 0, 255),
    Scalar(255, 255, 0),
    Scalar(0, 255, 255)
};

class VisionServer
{
private:
    ros::NodeHandle& nh;
    ros::Subscriber odom_sub;
    message_filters::Subscriber<sensor_msgs::Image> color_sub;
    message_filters::Subscriber<sensor_msgs::Image> depth_sub;
    message_filters::TimeSynchronizer<sensor_msgs::Image, sensor_msgs::Image> color_depth_sync;

    const int pub_result;
    ros::Publisher img_result_pub;
    Matrix3d inner_m;
    Matrix4d R_b_c;

    ros::ServiceServer cylinder_service;
    ros::ServiceServer circle_service;
    ros::ServiceServer switch_service;

    shared_ptr<CylinderFrontend> cylinder_frontend;
    shared_ptr<CylinderBackend> cylinder_backend;

    shared_ptr<CircleFrontend> circle_frontend;
    shared_ptr<CircleBackend> circle_backend;

    const string circle_frontend_method;

    Matrix4d R_w_b;
    bool color_depth_init;
    bool odom_init;

    int detect_mode;

    CylinderBackendResult_t cylinder_result;
    CircleBackendResult_t circle_result;

public:
    VisionServer(ros::NodeHandle& nh_, const FileStorage& fs): 
        nh(nh_), color_sub(nh, (string)fs["color_topic"], 1), depth_sub(nh, (string)fs["depth_topic"], 1), color_depth_sync(color_sub, depth_sub, 10), 
        circle_frontend_method((string)fs["circle_method"]), pub_result(fs["show_result"])
    {
        cylinder_frontend = make_shared<CylinderFrontend>(fs);
        cylinder_backend = make_shared<CylinderBackend>(fs);
        circle_frontend = make_shared<CircleFrontend>(fs);
        circle_backend = make_shared<CircleBackend>(fs);

        R_w_b = Matrix4d::Identity();
        color_depth_init = false;
        odom_init = false;

        detect_mode = 1;

        if(pub_result){
            img_result_pub = nh.advertise<sensor_msgs::Image>("vision_result", 100);
            cv::Mat cam_inner_cvmat, R_b_c_cvmat;
            fs["cam_inner"] >> cam_inner_cvmat; fs["body_T_cam"] >> R_b_c_cvmat;
            cv::cv2eigen(cam_inner_cvmat, inner_m); cv::cv2eigen(R_b_c_cvmat, R_b_c);
        }

        cylinder_service = nh.advertiseService((string)fs["cylinder_server_name"], &VisionServer::cylinder_srv_cb, this);
        circle_service = nh.advertiseService((string)fs["circle_server_name"], &VisionServer::circle_srv_cb, this);
        switch_service = nh.advertiseService((string)fs["switch_server_name"], &VisionServer::switch_srv_cb, this);
        odom_sub = nh.subscribe((string)fs["odom_topic"], 1, &VisionServer::odom_cb, this);
        color_depth_sync.registerCallback(&VisionServer::color_depth_cb, this);

        ROS_INFO("waiting odom and img...");
        ros::Rate rate(100);
        while(ros::ok() && (!color_depth_init || !odom_init)){
            ros::spinOnce();
            rate.sleep();
        }
    }

private:
    void cylinder_result_visualize(Mat& color_img, const vector<vector<Eigen::Vector2d>>& clusters)
    {
        for(int i = 0; i < clusters.size(); i++)
            for(const auto& point : clusters[i]){
                const Eigen::Vector4d p_c = R_b_c.inverse() * R_w_b.inverse() * Eigen::Vector4d(point.x(), point.y(), R_w_b(2, 3), 1);
                const Eigen::Vector3d p_pixel = inner_m * p_c.block<3, 1>(0, 0);
                const Point p(p_pixel.x() / p_pixel.z(), p_pixel.y() / p_pixel.z());
                circle(color_img, p, 2, i < 4 ? colors[i] : colors[4], -1);
            }
    
        std_msgs::Header header;
        header.stamp = ros::Time::now();
        img_result_pub.publish(cv_bridge::CvImage(header, "bgr8", color_img));
    }

    void cylinder_result_visualize(const Mat& color_img)
    {   
        std_msgs::Header header;
        header.stamp = ros::Time::now();
        img_result_pub.publish(cv_bridge::CvImage(header, "bgr8", color_img));
    }

    void circle_result_visualize(Mat& color_img, const CircleBackendResult_t& circle)
    {
        const Eigen::Vector3d vs = inner_m * circle.center;
        const Eigen::Vector3d end_point = circle.center - circle.direction;
        const Eigen::Vector3d v = inner_m * end_point;
        const Point2f sp(vs.x() / vs.z(), vs.y() / vs.z());
        const Point2f ep(v.x() / v.z(), v.y() / v.z());
        arrowedLine(color_img, sp, ep, Scalar(0, 0, 255), 3);

        std_msgs::Header header;
        header.stamp = ros::Time::now();
        img_result_pub.publish(cv_bridge::CvImage(header, "bgr8", color_img));
    }

    void circle_result_visualize(const Mat& color_img)
    {
        std_msgs::Header header;
        header.stamp = ros::Time::now();
        img_result_pub.publish(cv_bridge::CvImage(header, "bgr8", color_img));
    }

    void odom_cb(const nav_msgs::Odometry::ConstPtr& odom_msg)
    {
        if(!odom_init){
            odom_init = true;
            ROS_INFO("received odom!");
        }

        const auto& pose_msg = odom_msg->pose.pose.position;
        const auto& quat_msg = odom_msg->pose.pose.orientation;
        R_w_b.block<3, 3>(0, 0) = Eigen::Quaterniond(quat_msg.w, quat_msg.x, quat_msg.y, quat_msg.z).toRotationMatrix();
        R_w_b.block<3, 1>(0, 3) = Eigen::Vector3d(pose_msg.x, pose_msg.y, pose_msg.z);
        R_w_b.block<1, 4>(3, 0) << 0, 0, 0, 1;
    }

    void color_depth_cb(const sensor_msgs::Image::ConstPtr& color_msg, const sensor_msgs::Image::ConstPtr& depth_msg)
    {
        if(!color_depth_init){
            color_depth_init = true;
            ROS_INFO("received img!");
        }
        if(!odom_init)
            return;

        auto color_img = cv_bridge::toCvCopy(color_msg, "bgr8");
        auto depth_img = cv_bridge::toCvShare(depth_msg, depth_msg->encoding);

        if(detect_mode == 1){
            try{
                auto cylinder_begin = chrono::high_resolution_clock::now();
                auto cylinder_frontend_result = cylinder_frontend->cluster_frontend(depth_img->image, R_w_b);
                auto cylinder_backend_result = cylinder_backend->filter_backend(cylinder_frontend_result);
                auto cylinder_end = chrono::high_resolution_clock::now();
                ROS_INFO("cylinder time cost: %.3fms", chrono::duration_cast<chrono::microseconds>(cylinder_end - cylinder_begin).count() * 1e-3);
                ROS_INFO("cylinder cluster num: %zu", cylinder_frontend_result.cylinders.size());
                for(int i = 0; i < 4; i++)
                    ROS_INFO("cylinder %d: %.2f %.2f", i + 1, cylinder_backend_result.cylinders[i].x(), cylinder_backend_result.cylinders[i].y());

                cylinder_result = cylinder_backend_result;
                if(pub_result) cylinder_result_visualize(color_img->image, cylinder_frontend_result.clusters);
            } catch(const char* e)
            {
                ROS_ERROR("%s", e);
                if(pub_result) cylinder_result_visualize(color_img->image);
            }
        }
        else{
            try{
                auto circle_begin = chrono::high_resolution_clock::now();
                CircleFrontendResult_t circle_frontend_result;
                if(circle_frontend_method == "shape")
                    circle_frontend_result = circle_frontend->shape_frontend(color_img->image, depth_img->image);
                else
                    circle_frontend_result = circle_frontend->simple_depth_frontend(color_img->image, depth_img->image);
                auto circle_backend_result = circle_backend->ceres_backend(circle_frontend_result);
                auto circle_end = chrono::high_resolution_clock::now();
                ROS_INFO("circle time cost: %.3fms", chrono::duration_cast<chrono::microseconds>(circle_end - circle_begin).count() * 1e-3);
                ROS_INFO("circle center: %.2f %.2f %.2f", circle_backend_result.center.x(), circle_backend_result.center.y(), circle_backend_result.center.z());
                ROS_INFO("circle direction: %.2f %.2f %.2f", circle_backend_result.direction.x(), circle_backend_result.direction.y(), circle_backend_result.direction.z());

                circle_result = circle_backend_result;
                if(pub_result) circle_result_visualize(color_img->image, circle_backend_result);
            } catch(const char* e)
            {
                ROS_ERROR("%s", e);
                if(pub_result) circle_result_visualize(color_img->image);
            }
        }

        ROS_INFO("=========================");
    }

    bool cylinder_srv_cb(vision_server::cylinder::Request &req, vision_server::cylinder::Response &res)
    {
        res.cylinder1_x = cylinder_result.cylinders[0].x(); res.cylinder1_y = cylinder_result.cylinders[0].y();
        res.cylinder2_x = cylinder_result.cylinders[1].x(); res.cylinder2_y = cylinder_result.cylinders[1].y();
        res.cylinder3_x = cylinder_result.cylinders[2].x(); res.cylinder3_y = cylinder_result.cylinders[2].y();
        res.cylinder4_x = cylinder_result.cylinders[3].x(); res.cylinder4_y = cylinder_result.cylinders[3].y();

        return true;
    }

    bool circle_srv_cb(vision_server::circle::Request &req, vision_server::circle::Response &res)
    {
        res.pos_x = circle_result.center.x(); res.pos_y = circle_result.center.y(); res.pos_z = circle_result.center.z();
        res.direction_x = circle_result.direction.x(); res.direction_y = circle_result.direction.y(); res.direction_z = circle_result.direction.z();

        return true;
    }

    bool switch_srv_cb(vision_server::switch_mode::Request &req, vision_server::switch_mode::Response &res)
    {
        detect_mode = req.switch_to;

        return true;
    }
};
 
int main(int argc, char **argv)
{
    ros::init(argc, argv, "vision_server");
    ros::NodeHandle nh;

    if(argc < 2)
        ROS_WARN("config file path not provided!\n" "usage: rosrun vision_server vision_server [config file]");

    const string config_path = argv[1];

    FileStorage fs(config_path, FileStorage::READ);
    VisionServer vision_server(nh, fs);
    ros::spin();
 
    return 0;
}