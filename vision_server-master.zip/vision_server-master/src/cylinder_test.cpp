#include <ros/ros.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>

#include <cv_bridge/cv_bridge.h>

#include <sensor_msgs/Image.h>
#include <nav_msgs/Odometry.h>
#include <vision_server/circle.h>
#include <vision_server/cylinder.h>

#include <chrono>
#include "detector.hpp"

using namespace std;
using namespace cv;
using namespace Eigen;

const Scalar colors[]{
    Scalar(255, 0, 0),
    Scalar(0, 255, 0),
    Scalar(0, 0, 255),
    Scalar(255, 255, 0),
    Scalar(0, 255, 255)
};

class VisionServer
{
private:
    ros::NodeHandle& nh;

    ros::Subscriber odom_sub;
    ros::Subscriber depth_sub;

    shared_ptr<CylinderFrontend> cylinder_frontend;
    shared_ptr<CylinderBackend> cylinder_backend;

    Matrix4d R_w_b;
    bool depth_init;
    bool odom_init;

    Matrix3d inner_m;
    Matrix4d R_b_c;

public:
    VisionServer(ros::NodeHandle& nh_, const FileStorage& fs): 
        nh(nh_)
    {
        cylinder_frontend = make_shared<CylinderFrontend>(fs);
        cylinder_backend = make_shared<CylinderBackend>(fs);

        cv::Mat cam_inner_cvmat, R_b_c_cvmat;
        fs["cam_inner"] >> cam_inner_cvmat; fs["body_T_cam"] >> R_b_c_cvmat;
        cv::cv2eigen(cam_inner_cvmat, inner_m); cv::cv2eigen(R_b_c_cvmat, R_b_c);

        R_w_b = Matrix4d::Identity();
        depth_init = false;
        odom_init = false;

        odom_sub = nh.subscribe((string)fs["odom_topic"], 1, &VisionServer::odom_cb, this);
        depth_sub = nh.subscribe((string)fs["depth_topic"], 1, &VisionServer::depth_cb, this);

        ROS_INFO("waiting odom and img...");
        ros::Rate rate(100);
        while(ros::ok() && (!depth_init || !odom_init)){
            ros::spinOnce();
            rate.sleep();
        }
    }

private:
    void visualization(const Mat& depth_img, const vector<vector<Eigen::Vector2d>>& clusters)
    {
        Mat show_img;
        depth_img.convertTo(show_img, CV_8UC1);
        cvtColor(show_img, show_img, CV_GRAY2BGR);
        for(int i = 0; i < clusters.size(); i++)
            for(const auto& point : clusters[i]){
                const Eigen::Vector4d p_c = R_b_c.inverse() * R_w_b.inverse() * Eigen::Vector4d(point.x(), point.y(), R_w_b(2, 3), 1);
                const Eigen::Vector3d p_pixel = inner_m * p_c.block<3, 1>(0, 0);
                const Point p(p_pixel.x() / p_pixel.z(), p_pixel.y() / p_pixel.z());
                circle(show_img, p, 2, i < 4 ? colors[i] : colors[4], -1);
            }
        imshow("video", show_img);
        waitKey(1);
    }

    void odom_cb(const nav_msgs::Odometry::ConstPtr& odom_msg)
    {
        if(!odom_init){
            odom_init = true;
            ROS_INFO("received odom!");
        }

        const auto& pose_msg = odom_msg->pose.pose.position;
        const auto& quat_msg = odom_msg->pose.pose.orientation;
        R_w_b.block<3, 3>(0, 0) = Eigen::Quaterniond(quat_msg.w, quat_msg.x, quat_msg.y, quat_msg.z).toRotationMatrix();
        R_w_b.block<3, 1>(0, 3) = Eigen::Vector3d(pose_msg.x, pose_msg.y, pose_msg.z);
        R_w_b.block<1, 4>(3, 0) << 0, 0, 0, 1;
    }

    void depth_cb(const sensor_msgs::Image::ConstPtr& depth_msg)
    {
        if(!depth_init){
            depth_init = true;
            ROS_INFO("received img!");
        }
        if(!odom_init)
            return;

        auto depth_img = cv_bridge::toCvShare(depth_msg, depth_msg->encoding);
        try{
            auto cylinder_begin = chrono::high_resolution_clock::now();
            auto cylinder_frontend_result = cylinder_frontend->cluster_frontend(depth_img->image, R_w_b);
            auto cylinder_backend_result = cylinder_backend->filter_backend(cylinder_frontend_result);
            auto cylinder_end = chrono::high_resolution_clock::now();
            ROS_INFO("cylinder time cost: %.3fms", chrono::duration_cast<chrono::microseconds>(cylinder_end - cylinder_begin).count() * 1e-3);
            ROS_INFO("cylinder cluster num: %zu", cylinder_frontend_result.cylinders.size());
            for(int i = 0; i < 4; i++)
                ROS_INFO("cylinder %d: %.2f %.2f", i + 1, cylinder_backend_result.cylinders[i].x(), cylinder_backend_result.cylinders[i].y());

            ROS_INFO("=========================");

            visualization(depth_img->image, cylinder_frontend_result.clusters);
        } catch(const char* e)
        {
            ROS_ERROR("%s", e);
            //显示图像
            Mat show_img;
            depth_img->image.convertTo(show_img, CV_8UC1);
            cvtColor(show_img, show_img, CV_GRAY2BGR);
            imshow("video", show_img);
            waitKey(1);
        }
    }
};
 
int main(int argc, char **argv)
{
    ros::init(argc, argv, "cylinder_test");
    ros::NodeHandle nh;

    if(argc < 2)
        ROS_WARN("config file path not provided!\n" "usage: rosrun vision_server vision_server [config file]");

    const string config_path = argv[1];

    FileStorage fs(config_path, FileStorage::READ);
    VisionServer vision_server(nh, fs);
    ros::spin();
 
    return 0;
}