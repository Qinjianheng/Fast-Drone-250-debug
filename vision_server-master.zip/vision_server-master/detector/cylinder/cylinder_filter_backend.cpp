#include <iostream>

#include "detector.hpp"

using namespace std;

CylinderBackendResult_t CylinderBackend::filter_backend(const CylinderFrontendResult_t& input)
{
    if(!init && input.cylinders.size() > 0){
        Eigen::Vector2d min_x_p(-1, -1);
        for(const auto& center : input.cylinders)
            if(min_x_p.x() < 0 || center.x() < min_x_p.x())
                min_x_p = center;
        double x_diff = min_x_p.x() - cylinders[0].x();
        for(int i = 0; i < 4; i++){
            cylinders[i].x() += x_diff;
            cylinders[i].y() = min_x_p.y();
        }
        init = true;
    }

    for(const auto& center : input.cylinders)
    {
        double min_dist = -1;
        int ci;
        for(int i = 0; i < 4; i++){
            const double temp_dist = (cylinders[i] - center).norm();
            if(min_dist < 0 || temp_dist < min_dist){
                min_dist = temp_dist;
                ci = i;
            }
        }

        if(min_dist < 0 || min_dist > max_match_dist)
            continue;
        
        cylinders[ci] = center;
    }

    CylinderBackendResult_t res;
    for(int i = 0; i < 4; i++)
        res.cylinders[i] = cylinders[i];
    return res;
}