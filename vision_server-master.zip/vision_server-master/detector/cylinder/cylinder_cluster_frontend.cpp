#include <iostream>

#include "detector.hpp"
#include "math_utils.hpp"

using namespace std;
using namespace cv;
using namespace Eigen;

void sample(const Mat& depth_img, const Matrix4d& R_w_b, const CylinderFrontend::Params& params, vector<Vector2d>& sample_out)
{
    double *wx = new double[depth_img.rows * depth_img.cols];
    double *wy = new double[depth_img.rows * depth_img.cols];
    int available_pixel = 0;
    for(int y = 0; y < depth_img.rows; y++){
        const float *depth_row = depth_img.ptr<float>(y);
        for(int x = 0; x < depth_img.cols; x++){
            const double depth = depth_row[x];
            if(isnan(depth) || fabs(depth) < params.depth_min_thr || fabs(depth) > params.depth_max_thr)
                continue;
            const Vector3d point_c_so3 = params.inner_m_inv * Vector3d(depth * x, depth * y, depth);
			const Vector4d point_c(point_c_so3.x(), point_c_so3.y(), point_c_so3.z(), 1);
            const Vector4d point_w = R_w_b * params.R_b_c * point_c;
            if(point_w.z() < params.height_min_thr || point_w.z() > params.height_max_thr)
                continue;
            wx[available_pixel] = point_w.x();
            wy[available_pixel++] = point_w.y();
        }
    }

    int step = available_pixel / params.cnt;
    step = step > 0 ? step : 1;

    for(int i = 0; i < available_pixel; i+=step)
		sample_out.push_back(Vector2d(wx[i], wy[i]));
    
    delete[] wx;
    delete[] wy;
}

inline double cross2(const Vector2d a, const Vector2d b)
{
    return a.x() * b.y() - b.x() * a.y();
}

CylinderFrontendResult_t CylinderFrontend::cluster_frontend(const Mat& depth_img, const Matrix4d& R_w_b) const
{
    if(depth_img.channels() != 1 || depth_img.depth() != CV_32FC1)
		throw "input not correct!";

    vector<Vector2d> sample_points;
    sample(depth_img, R_w_b, params, sample_points);
    if(sample_points.size() < 0.5 * params.cnt)
        throw "sample point too few!";

    //dbscan聚类
    vector<vector<Vector2d>> clusters;
    dbscan<Vector2d>(sample_points, params.dbscan_eps, params.dbscan_minpts, clusters, [](const Vector2d&v1, const Vector2d& v2) { return(v1 - v2).norm(); });

    CylinderFrontendResult_t res;
    const Vector2d p_w = R_w_b.block<2, 1>(0, 3);
    const double yaw = R_w_b.block<3, 3>(0, 0).eulerAngles(2, 1, 0).x();
    const Vector2d facing(cos(yaw), sin(yaw));
    for(auto& cluster : clusters){
        if(cluster.size() < 3)
            continue;
        std::sort(cluster.begin(), cluster.end(), [&](const Vector2d& a, const Vector2d b)->bool{ 
            const Vector2d va = a - p_w;
            const Vector2d vb = b - p_w;
            return cross2(facing, va) / va.norm() < cross2(facing, vb) / vb.norm();
        });
        if((cluster.front() - cluster.back()).norm() < 1.6 * params.R)
            continue;
        const Vector2d direction = cluster[cluster.size() / 2] - p_w;
        res.clusters.push_back(cluster);
        res.cylinders.push_back(p_w + direction + direction.normalized() * params.R);
    }
    return res;
}