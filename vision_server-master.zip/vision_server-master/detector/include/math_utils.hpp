#pragma once
#include <vector>
#include <functional>
#include <Eigen/Eigen>

template<class EigenContainerType>
double z_score_erase(EigenContainerType& points, const double threshold = 3)
{
    double sum = 0;
	for(const auto& point : points)
		sum += point.z();
	const double mean = sum / points.size();

	double squire_sum = 0;
	for(const auto& point : points)
		squire_sum += (point.z() - mean) * (point.z() - mean);
	const double std_dev = sqrt(squire_sum / (points.size() - 1));

	for(auto iter = points.begin(); iter != points.end(); iter++){
		const double z_score = fabs(iter->z() - mean) / std_dev;
		if(z_score > threshold){
			sum -= iter->z();
			points.erase(iter--);
		}
	}

	return sum / points.size();
}

template<class EigenContainerType>
Eigen::Vector3d get_center_init(const EigenContainerType& points, const double ave_depth)
{
    double sum_x = 0, sum_y = 0;
    for(const auto& p : points){
        sum_x += p.x();
        sum_y += p.y();
    }
    const double cx = sum_x / points.size();
    const double cy = sum_y / points.size();
    return Eigen::Vector3d(cx, cy, ave_depth);
}

template<class EigenContainerType>
Eigen::Vector3d get_direction_init(const EigenContainerType& points, const double ave_depth)
{
    auto max_iter = points.begin(), min_iter = points.begin(), mid_iter = points.begin();

	for(auto iter = points.begin(); iter != points.end(); iter++){
		if(iter->z() > max_iter->z())
			max_iter = iter;
		if(iter->z() < min_iter->z())
			min_iter = iter;
		if(fabs(iter->z() - ave_depth) < fabs(mid_iter->z() - ave_depth))
			mid_iter = iter;
	}

	const auto v1 = *max_iter - *min_iter;
	const auto v2 = *min_iter - *mid_iter;
	const auto v3 = *mid_iter - *max_iter;

	Eigen::Matrix<double, 3, 2> A;
	Eigen::Vector3d B;
	A << v1.x(), v1.y(), v2.x(), v2.y(), v3.x(), v3.y();
	B << -v1.z(), -v2.z(), -v3.z();
	Eigen::Matrix2d Phi_inv;
	bool invertible;
	(A.transpose() * A).computeInverseWithCheck(Phi_inv, invertible);
	if(!invertible)
		return Eigen::Vector3d(0, 0, 1);
	else{
		const Eigen::Vector2d res = (Phi_inv * A.transpose() * B).normalized();
		return Eigen::Vector3d(res.x(), res.y(), 1).normalized();
	}
}

template<class T>
void dbscan(const std::vector<T>& points, double eps, int minPts, std::vector<std::vector<T>>& clusters_out, const std::function<double(const T&, const T&)>& norm_func)
{
    std::vector<std::vector<int>> clusters;
    std::vector<bool> visited(points.size(), false);

    int clusterId = 0;
    for (int i = 0; i < points.size(); i++) {
        if (visited[i]) continue;
        visited[i] = true;

        std::vector<int> neighborPts;
        for (int j = 0; j < points.size(); j++) {
            if (i == j) continue;
            if (norm_func(points[i], points[j]) < eps)
            neighborPts.push_back(j);
        }

        if (neighborPts.size() < minPts) {
            visited[i] = false;
        } else {
            std::vector<int> c;
            c.push_back(i);
            clusters.push_back(c);
            
            std::vector<int> seeds = neighborPts;
            while (!seeds.empty()) {
                int currentP = seeds.back();
                seeds.pop_back();
                
                if (visited[currentP]) continue;
                
                visited[currentP] = true;
                clusters.back().push_back(currentP);
                
                const T& point = points[currentP];
                int numNeighbors = 0;
                for (int j = 0; j < points.size(); j++)
                    if (norm_func(point, points[j]) < eps && !visited[j]) {
                            seeds.push_back(j);
                            numNeighbors++;
                    }
                
                if (numNeighbors >= minPts)
                    neighborPts.insert(neighborPts.end(), seeds.begin(), seeds.end());
            }
            clusterId++;
        }
    }

    for(const auto& cluster : clusters){
        std::vector<T> temp(cluster.size());
        for(int i = 0; i < cluster.size(); i++)
            temp[i] = points[cluster[i]];
        clusters_out.push_back(std::move(temp));
    }
}