#pragma once
#include <list>
#include <vector>
#include "Eigen/Eigen"
#include <opencv2/opencv.hpp>
#include <opencv2/core/eigen.hpp>

/********************/
/*    圆柱检测相关    */
/********************/

struct CylinderFrontendResult_t
{
    std::vector<std::vector<Eigen::Vector2d>> clusters; // 聚类点
    std::vector<Eigen::Vector2d> cylinders; // 聚类中心坐标
};

struct CylinderBackendResult_t
{
    Eigen::Vector2d cylinders[4]; // 圆柱2d坐标
};

class CylinderFrontend
{
public:
    struct Params{
        Eigen::Matrix3d inner_m_inv;  // 内参矩阵
        Eigen::Matrix4d R_b_c;
        double R;
        double depth_min_thr;  // 深度滤波最小值
        double depth_max_thr;  // 深度滤波最大值
        double height_min_thr;
        double height_max_thr;
        int cnt;
        double dbscan_eps;
        int dbscan_minpts;
    };
private:
    const Params params;

    static Params get_params(const cv::FileStorage& fs)
    {
        Params params_;

        cv::Mat cam_inner_cvmat, R_b_c_cvmat;
        fs["cam_inner"] >> cam_inner_cvmat; fs["body_T_cam"] >> R_b_c_cvmat;
        Eigen::Matrix3d cam_inner; Eigen::Matrix4d R_b_c;
        cv::cv2eigen(cam_inner_cvmat, cam_inner); cv::cv2eigen(R_b_c_cvmat, R_b_c);

        params_.inner_m_inv = cam_inner.inverse();
        params_.R_b_c = R_b_c;
        fs["cylinder_R"] >> params_.R;
        fs["depth_min_thr"] >> params_.depth_min_thr;
        fs["depth_max_thr"] >> params_.depth_max_thr;
        fs["height_min_thr"] >> params_.height_min_thr;
        fs["height_max_thr"] >> params_.height_max_thr;
        fs["cylinder_sample_cnt"] >> params_.cnt;
        fs["cylinder_dbscan_eps"] >> params_.dbscan_eps;
        fs["cylinder_dbscan_minpts"] >> params_.dbscan_minpts;

        return params_;
    }

public:
    CylinderFrontend(const Params& params_): params(params_) { ; }
    CylinderFrontend(const cv::FileStorage& fs): params(get_params(fs)) { ; }
    
    CylinderFrontendResult_t cluster_frontend(const cv::Mat& depth_img, const Eigen::Matrix4d& R_w_b)const;
};

class CylinderBackend
{
public:
    struct Params{
        double max_match_dist;
        Eigen::Vector2d cylinders_init[4];
    };
private:
    const double max_match_dist;
    bool init;
    Eigen::Vector2d cylinders[4];
public:
    CylinderBackend(const Params& params_): max_match_dist(params_.max_match_dist){
        init = false;
        for(int i = 0; i < 4; i++)
            cylinders[i] = params_.cylinders_init[i];
    }
    CylinderBackend(const cv::FileStorage& fs): max_match_dist(fs["cylinder_max_match_distance"]){
        init = false;
        for(int i = 1; i <= 4; i++)
            cylinders[i - 1] = Eigen::Vector2d((double)fs["cylinder" + std::to_string(i) + "_x"], (double)fs["cylinder" + std::to_string(i) + "_y"]);
    }
    
    CylinderBackendResult_t filter_backend(const CylinderFrontendResult_t& input);
};


/********************/
/*    圆环检测相关    */
/********************/

struct CircleFrontendResult_t
{
    std::list<Eigen::Vector3d> points; // 圆环点(相机坐标系，三维)，与vector相比，list（链表）剔除离群点更有效率 d
    Eigen::Vector3d center_init; // 圆心初值
    Eigen::Vector3d direction_init; // 法向量初值
};

struct CircleBackendResult_t
{
    Eigen::Vector3d center;  // 圆心
    Eigen::Vector3d direction;  // 法向量
};

class CircleFrontend
{
public:
    struct Params{
        cv::Scalar hsv_min;
        cv::Scalar hsv_max;
        Eigen::Matrix3d inner_m_inv;  // 内参矩阵
        double depth_min_thr;  // 深度滤波最小值
        double depth_max_thr;  // 深度滤波最大值
        int cnt;  // 采样点个数
    };
private:
    const Params params;

    static Params get_params(const cv::FileStorage& fs)
    {
        Params params_;

        cv::Mat cam_inner_cvmat;
        fs["cam_inner"] >> cam_inner_cvmat;
        Eigen::Matrix3d cam_inner;
        cv::cv2eigen(cam_inner_cvmat, cam_inner);
        
        params_.inner_m_inv = cam_inner.inverse();
        params_.hsv_min = cv::Scalar((int)fs["circle_h_min"], (int)fs["circle_s_min"], (int)fs["circle_v_min"]);
        params_.hsv_max = cv::Scalar((int)fs["circle_h_max"], (int)fs["circle_s_max"], (int)fs["circle_v_max"]);
        fs["depth_min_thr"] >> params_.depth_min_thr;
        fs["depth_max_thr"] >> params_.depth_max_thr;
        fs["circle_sample_cnt"] >> params_.cnt;

        return params_;
    }

public:
    CircleFrontend(const Params& params_): params(params_) { ; }
    CircleFrontend(const cv::FileStorage& fs): params(get_params(fs)) { ; }
    
    CircleFrontendResult_t shape_frontend(cv::Mat& color_img, const cv::Mat& depth_img)const;
    CircleFrontendResult_t simple_depth_frontend(cv::Mat& color_img, const cv::Mat& depth_img)const;
};


class CircleBackend
{
public:
    struct Params
    {
        double R;
    };
private:
    const Params params;

    static Params get_params(const cv::FileStorage& fs)
    {
        Params params_;

        fs["circle_R"] >> params_.R;

        return params_;
    }
public:
    CircleBackend(const Params& params_): params(params_) { ; }
    CircleBackend(const cv::FileStorage& fs): params(get_params(fs)) { ; }

    CircleBackendResult_t ceres_backend(const CircleFrontendResult_t& input)const;
};