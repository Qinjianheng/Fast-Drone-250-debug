// 形态学视觉前端
#include <iostream>
#include <opencv2/imgproc.hpp>

#include "detector.hpp"
#include "math_utils.hpp"

using namespace cv;
using namespace std;
using namespace Eigen;

bool get_ellipse(Mat& color_img, Mat& mask, const Mat& depth_img, const CircleFrontend::Params& params, RotatedRect& rt)
{
	//深度滤波
	for(int y = 0; y < mask.rows; y++){
        uint8_t *mask_row = mask.ptr<uint8_t>(y);
        const float *depth_row = depth_img.ptr<float>(y);
        for(int x = 0; x < mask.cols; x++){
            const double depth = depth_row[x];
            if(mask_row[x] && (isnan(depth) || fabs(depth) < params.depth_min_thr || fabs(depth) > params.depth_max_thr))
                mask_row[x] = 0;
        }
    }

	//找轮廓
	vector<vector<Point>> contours_list;
	vector<cv::Vec4i> hierarchy;  // 包含轮廓层级信息
	findContours(mask, contours_list, hierarchy, RETR_TREE, CHAIN_APPROX_TC89_KCOS);

	double _outer_max_area = -1;
	double _inner_max_area = -1;
	int outer_idx = -1;
	int inner_idx = -1;

	// 遍历所有具有子轮廓的最外层轮廓，并找出面积最大的轮廓
	for(int i = 0; i < contours_list.size(); i++){
		// 如果存在父节点或者无子轮廓，则忽略该轮廓
		if(hierarchy[i][3] >= 0)
			continue;
		const double area = fabs(contourArea(contours_list[i]));
		if(area > _outer_max_area){
			_outer_max_area = area;
			outer_idx = i;
		}
	}
	if(outer_idx < 0 || contours_list[outer_idx].size() < 5)
		return false;

	// 当前轮廓的所有同级子轮廓中寻找面积最大的子轮廓
	int temp_inner_idx = hierarchy[outer_idx][2];
	while(temp_inner_idx >= 0){
		const double area = fabs(contourArea(contours_list[temp_inner_idx]));
		if(area > _inner_max_area){
			_inner_max_area = area;
			inner_idx = temp_inner_idx;
		}
		temp_inner_idx = hierarchy[temp_inner_idx][0];
	}

	// 以下条件描述了这样一种情况：外圆和内圆在图像中都不完整。这种情况下，内轮廓和外轮廓会合并成一个轮廓
	if(inner_idx < 0 || contours_list[inner_idx].size() < 5 || _inner_max_area / _outer_max_area < 0.5){
		rt = fitEllipse(contours_list[outer_idx]);
		/*
		const vector<Point>& points = contours_list[outer_idx];
		vector<Point> down_sample_points;
		int step = points.size() / 200;
		step = step > 0 ? step : 1;
		for(int i = 0; i < points.size(); i += step){
			if(points[i].x <= 10 || points[i].x >= mask.cols - 10 || points[i].y <= 10 || points[i].y >= mask.rows - 10)
				continue;
			else
				down_sample_points.push_back(points[i]);
    	}

		vector<vector<Point>> clusters;
		dbscan<Point>(down_sample_points, ceil(step*sqrt(2)), 2, clusters, [](const Point& p1, const Point& p2) { return norm(p1 - p2); });
		int max1_idx = 0, max2_idx = -1;
		for(int i = 1; i < clusters.size(); i++){
			if(clusters[i].size() > clusters[max1_idx].size()){
				max2_idx = max1_idx;
				max1_idx = i;
			}
			else if(max2_idx < 0 || clusters[i].size() > clusters[max2_idx].size())
				max2_idx = i;
		}
		if(max2_idx < 0 || clusters[max1_idx].size() < 5 || clusters[max2_idx].size() < 5){
			cout << clusters.size() << endl;
			return false;
		}

		RotatedRect rt_0 = fitEllipse(clusters[max1_idx]);
		RotatedRect rt_1 = fitEllipse(clusters[max2_idx]);
		// 平均旋转矩形
		rt = RotatedRect((rt_0.center + rt_1.center) / 2, 
							Size((rt_0.size.width + rt_1.size.width) / 2, (rt_0.size.height + rt_1.size.height) / 2), 
							rt_0.angle);  // (rt.angle + rt_child.angle) / 2
		*/
		
	}
	else{
		RotatedRect rt_outer = fitEllipse(contours_list[outer_idx]);
		RotatedRect rt_inner = fitEllipse(contours_list[inner_idx]);
		// 平均旋转矩形
		rt = RotatedRect((rt_outer.center + rt_inner.center) / 2, 
							Size((rt_outer.size.width + rt_inner.size.width) / 2, (rt_outer.size.height + rt_inner.size.height) / 2), 
							rt_outer.angle);  // (rt.angle + rt_child.angle) / 2
	}


	return true;
}

void sample_ellipse(const Mat& depth_img, const RotatedRect& rt, const CircleFrontend::Params& params, list<Vector3d>& sample_out)
{
	Point2f vertices[4];
	rt.points(vertices);
	const double a = norm(vertices[0] - vertices[1]) / 2;  // 半轴
	const double b = norm(vertices[1] - vertices[2]) / 2;  // 半轴
	double theta = atan((vertices[0].y - vertices[1].y) / (vertices[0].x - vertices[1].x));

	for(int i = 0; i < params.cnt; i++)
	{
		const double ca = cos(2 * M_PI * i / params.cnt);
		const double sa = sin(2 * M_PI * i / params.cnt);
		const double t = sqrt(1 / (ca*ca/a/a + sa*sa/b/b));
		Point2f epf = Point2f(t * ca, t * sa);
		epf = Point2f(epf.x * cos(theta) - epf.y * sin(theta) + rt.center.x,
					  epf.x * sin(theta) + epf.y * cos(theta) + rt.center.y);
		const Point ep(epf.x, epf.y);
		if(ep.x <= 0 || ep.x >= depth_img.cols || ep.y <= 0 || ep.y >= depth_img.rows)
			continue;
		const double depth = depth_img.at<float>(ep);
		//cout << depth << endl;
		if(fabs(depth) < params.depth_min_thr || fabs(depth) > params.depth_max_thr || isnan(depth))
			continue;
		sample_out.push_back(params.inner_m_inv * Vector3d(depth * ep.x, depth * ep.y, depth));
	}
}

CircleFrontendResult_t CircleFrontend::shape_frontend(Mat& color_img, const Mat& depth_img)const
{
	if(color_img.size != depth_img.size || depth_img.channels() != 1 || depth_img.depth() != CV_32FC1)
		throw "frontend error: input not correct!";

	//BGR转HSV
	Mat imgHSV;
	cvtColor(color_img, imgHSV, COLOR_BGR2HSV);

	//找颜色区域
	Mat mask;
	inRange(imgHSV, params.hsv_min, params.hsv_max, mask);

	//闭运算
	//Mat dilate_mask;
	//dilate(mask, dilate_mask, getStructuringElement(MorphShapes::MORPH_ELLIPSE, Size(15, 15)));
	//erode(dilate_mask, mask, getStructuringElement(MorphShapes::MORPH_ELLIPSE, Size(15, 15)));

	// 平均旋转矩形
	RotatedRect rt;
	if(!get_ellipse(color_img, mask, depth_img, params, rt))
		throw "frontend error: cannot find ellipse!";

	//debug
	ellipse(color_img, rt, Scalar(0, 255, 0), 2);
	
	// 在旋转矩形对应的椭圆上采样空间点
	list<Vector3d> sample_points;
	sample_ellipse(depth_img, rt, params, sample_points);
	if(sample_points.size() < 10)
		throw "frontend error: low quality ellipse!";

	// 执行3倍sigma离群深度剔除，并返回深度的平均值
	const double ave_depth = z_score_erase(sample_points);

	// 使用椭圆中心和圆环平均深度构建圆心坐标初始值
	const Vector3d center_init = params.inner_m_inv * Vector3d(ave_depth * rt.center.x, ave_depth* rt.center.y, ave_depth);
	// pick三个点解正规方程，计算粗略的法向量
	const Vector3d direction_init = get_direction_init(sample_points, ave_depth);

	CircleFrontendResult_t res;
	res.points = std::move(sample_points);
	res.center_init = center_init;
	res.direction_init = direction_init;

	return res;
}
