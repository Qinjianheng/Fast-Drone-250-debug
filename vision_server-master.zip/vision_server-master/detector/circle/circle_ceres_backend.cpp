#include <iostream>

#include "detector.hpp"

#include <ceres/ceres.h>

using namespace std;
using namespace Eigen;

struct SphereCost{
    const Vector3d point;
    const double R;

    SphereCost(const Vector3d& point_, const double R_): point(point_), R(R_) {}

    template<typename T>
    bool operator()(const T *const center_, const T *const n_, T *residual) const {  // 输入: 中心坐标+二自由度法向量，1维残差
        const Matrix<T, 3, 1> center(center_[0], center_[1], center_[2]);
        const Matrix<T, 3, 1> n = Matrix<T, 3, 1>(n_[0], n_[1], T(1)).normalized();
        const Matrix<T, 3, 1> CP(point - center);
        residual[0] = R - (CP - CP.dot(n)*n).norm();

        return true;
    }
};

struct PlaneCost{
    const Vector3d point;
    const double R;

    PlaneCost(const Vector3d& point_, const double R_): point(point_), R(R_) {}

    template<typename T>
    bool operator()(const T *const center_, const T *const n_, T *residual) const {  // 输入: 中心坐标+二自由度法向量，1维残差
        const Matrix<T, 3, 1> center(center_[0], center_[1], center_[2]);
        const Matrix<T, 3, 1> n(n_[0], n_[1], T(1));
        const Matrix<T, 3, 1> CP(point - center);
        residual[0] = CP.dot(n);

        return true;
    }
};

CircleBackendResult_t CircleBackend::ceres_backend(const CircleFrontendResult_t& input)const
{
    assert(fabs(input.direction_init.z()) > 1e-3);

    ceres::Problem problem;
    double center[3] = {input.center_init.x(), input.center_init.y(), input.center_init.z()};
    double direction[2] = {input.direction_init.x() / input.direction_init.z(), input.direction_init.y() / input.direction_init.z()};
    for(const auto& point : input.points)
    {
        problem.AddResidualBlock(new ceres::AutoDiffCostFunction<SphereCost, 1, 3, 2>(new SphereCost(point, params.R)), 
            new ceres::CauchyLoss(1), 
            center, direction);
        problem.AddResidualBlock(new ceres::AutoDiffCostFunction<PlaneCost, 1, 3, 2>(new PlaneCost(point, params.R)), 
            new ceres::CauchyLoss(0.5), 
            center, direction);
    }
    ceres::Solver::Options options;
    options.max_num_iterations = 100;             // 最大迭代次数
    options.linear_solver_type = ceres::DENSE_NORMAL_CHOLESKY; // 线性求解器类型
    //options.minimizer_progress_to_stdout = false;  // 输出优化过程到终端
    //options.num_threads = 8;

    ceres::Solver::Summary summary;               // 定义优化结果的汇总信息
    ceres::Solve(options, &problem, &summary); // 求解

    //cout << summary.BriefReport() << endl;
    if(!summary.IsSolutionUsable())
        throw "backend error: optimization result is unavailable!";

    CircleBackendResult_t res;
    res.center = Vector3d(center);
    res.direction = Vector3d(direction[0], direction[1], 1);
    res.direction.normalize();

    return res;
}
