// 简单下采样视觉前端
#include <iostream>

#include "detector.hpp"

using namespace cv;
using namespace std;
using namespace Eigen;

void sample_mask(Mat& color_img, const Mat& depth_img, const Mat& mask, const Matrix3d& inner_m_inv, list<Vector3d>& sample_out, const double depth_min_thr, const double depth_max_thr, const int cnt)
{
	uint16_t pixel_y[1280*720];
	uint16_t pixel_x[1280*720];

	int available_pixel = 0;
	for(int y = 0; y < mask.rows; y++){
        const uint8_t *mask_row = mask.ptr<uint8_t>(y);
        const float *depth_row = depth_img.ptr<float>(y);
        for(int x = 0; x < mask.cols; x++){
            const double depth = depth_row[x];
            if(!mask_row[x] || isnan(depth) || fabs(depth) < depth_min_thr || fabs(depth) > depth_max_thr)
                continue;
			pixel_y[available_pixel] = y;
			pixel_x[available_pixel++] = x;
        }
    }

	int down_sample_step = available_pixel / cnt;
	if(down_sample_step <= 0)
		down_sample_step = 1;

    for(int i = 0; i < available_pixel; i+=down_sample_step){
        Vec3b* color_row = color_img.ptr<Vec3b>(pixel_y[i]);
        const uint8_t *mask_row = mask.ptr<uint8_t>(pixel_y[i]);
        const float *depth_row = depth_img.ptr<float>(pixel_y[i]);

		const double depth = depth_row[pixel_x[i]];
		sample_out.push_back(inner_m_inv * Vector3d(depth * pixel_x[i], depth * pixel_y[i], depth));
		//debug
		color_row[pixel_x[i]] = Vec3b(0, 255, 0);
    }
}

CircleFrontendResult_t CircleFrontend::simple_depth_frontend(Mat& color_img, const Mat& depth_img) const
{
	if(color_img.size != depth_img.size || depth_img.channels() != 1 || depth_img.depth() != CV_32FC1)
		throw "input not correct!";

	static const Scalar hsv_lower(100, 43, 200);  // 100, 43, 46
	static const Scalar hsv_upper(124, 255, 255); // 124, 255, 255

	//BGR转HSV
	Mat imgHSV;
	cvtColor(color_img, imgHSV, COLOR_BGR2HSV);

	//找颜色区域
	Mat mask;
	inRange(imgHSV, hsv_lower, hsv_upper, mask);

	//闭运算
	Mat dilate_mask;
	dilate(mask, dilate_mask, getStructuringElement(MorphShapes::MORPH_ELLIPSE, Size(15, 15)));
	erode(dilate_mask, mask, getStructuringElement(MorphShapes::MORPH_ELLIPSE, Size(15, 15)));
	
	// 在mask上采样空间点
	list<Vector3d> sample_points;
	sample_mask(color_img, depth_img, mask, inner_m_inv, sample_points, depth_min_thr, depth_max_thr, cnt);
	if(sample_points.size() < 10)
		throw "frontend error: low quality sample points!";

	// 执行3倍sigma离群深度剔除，并返回深度的平均值
	const double ave_depth = z_score_erase(sample_points);

	// 计算x和y的平均值，结合平均深度作为中心的初始值。
	const Vector3d center_init = get_center_init(sample_points, ave_depth);
	// pick三个点解正规方程，计算粗略的法向量
	const Vector3d direction_init = get_direction_init(sample_points, ave_depth);

	CircleFrontendResult_t out;
	out.points = std::move(sample_points);
	out.center_init = center_init;
	out.direction_init = direction_init;

	return out;
}
