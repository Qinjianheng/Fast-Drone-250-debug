#include <vector>
#include <functional>

using namespace std;

template<class T>
void dbscan(const vector<T>& points, double eps, int minPts, vector<vector<T>>& clusters_out, const function<double(const T&, const T&)>& norm_func)
{
    vector<vector<int>> clusters;
    vector<bool> visited(points.size(), false);

    int clusterId = 0;
    for (int i = 0; i < points.size(); i++) {
        if (visited[i]) continue;
        visited[i] = true;

        vector<int> neighborPts;
        for (int j = 0; j < points.size(); j++) {
            if (i == j) continue;
            if (norm_func(points[i], points[j]) < eps)
            neighborPts.push_back(j);
        }

        if (neighborPts.size() < minPts) {
            visited[i] = false;
        } else {
            vector<int> c;
            c.push_back(i);
            clusters.push_back(c);
            
            vector<int> seeds = neighborPts;
            while (!seeds.empty()) {
                int currentP = seeds.back();
                seeds.pop_back();
                
                if (visited[currentP]) continue;
                
                visited[currentP] = true;
                clusters.back().push_back(currentP);
                
                const T& point = points[currentP];
                int numNeighbors = 0;
                for (int j = 0; j < points.size(); j++)
                    if (norm_func(point, points[j]) < eps && !visited[j]) {
                            seeds.push_back(j);
                            numNeighbors++;
                    }
                
                if (numNeighbors >= minPts)
                    neighborPts.insert(neighborPts.end(), seeds.begin(), seeds.end());
            }
            clusterId++;
        }
    }

    for(const auto& cluster : clusters){
        vector<T> temp(cluster.size());
        for(int i = 0; i < cluster.size(); i++)
            temp[i] = points[cluster[i]];
        clusters_out.push_back(std::move(temp));
    }
}