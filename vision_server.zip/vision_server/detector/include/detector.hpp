#pragma once
#include <list>
#include <vector>
#include "Eigen/Eigen"
#include <opencv2/opencv.hpp>

double z_score_erase(std::list<Eigen::Vector3d>& points, const double threshold = 3);
Eigen::Vector3d get_center_init(const std::list<Eigen::Vector3d>& points, const double ave_depth);
Eigen::Vector3d get_direction_init(const std::list<Eigen::Vector3d>& points, const double ave_depth);

/********************/
/*    圆柱检测相关    */
/********************/

struct CylinderFrontendResult_t
{
    std::vector<std::vector<Eigen::Vector2d>> clusters; // 聚类点
    std::vector<Eigen::Vector2d> cylinders; // 聚类中心坐标
};

struct CylinderBackendResult_t
{
    Eigen::Vector2d cylinders[4]; // 圆柱2d坐标
};

class CylinderFrontend
{
private:
    const Eigen::Matrix3d inner_m_inv;  // 内参矩阵
    const Eigen::Matrix4d R_b_c;
    const double R;
    const double depth_min_thr;  // 深度滤波最小值
    const double depth_max_thr;  // 深度滤波最大值
    const double height_min_thr;
    const double height_max_thr;
    const int cnt;
    const double dbscan_eps;
    const int dbscan_minpts;

public:
    CylinderFrontend(const Eigen::Matrix3d& inner_m_, const Eigen::Matrix4d& R_b_c_, const double R_, const double depth_min_thr_=0.1, const double depth_max_thr_=6, const double height_min_thr_=1, const double height_max_thr_=1.5, const int cnt_=100, const double dbscan_eps_=0.1, const double dbscan_minpts_=5):
        inner_m_inv(inner_m_.inverse()), R_b_c(R_b_c_), R(R_), 
        depth_min_thr(depth_min_thr_), depth_max_thr(depth_max_thr_), height_min_thr(height_min_thr_), height_max_thr(height_max_thr_), cnt(cnt_), dbscan_eps(dbscan_eps), dbscan_minpts(dbscan_minpts_) { ; }
    
    CylinderFrontendResult_t cluster_frontend(const cv::Mat& depth_img, const Eigen::Matrix4d& R_w_b)const;
};

class CylinderBackend
{
private:
    Eigen::Vector2d cylinders[4];
    double max_match_dist;
    bool init;
public:
    CylinderBackend(const Eigen::Vector2d& cylinder1_init, const Eigen::Vector2d& cylinder2_init, const Eigen::Vector2d& cylinder3_init, const Eigen::Vector2d& cylinder4_init, double max_match_dist_ = 2): 
        cylinders{cylinder1_init, cylinder2_init, cylinder3_init, cylinder4_init}, max_match_dist(max_match_dist_), init(false) { ; }
    CylinderBackendResult_t filter_backend(const CylinderFrontendResult_t& input);
};


/********************/
/*    圆环检测相关    */
/********************/

struct CircleFrontendResult_t
{
    std::list<Eigen::Vector3d> points; // 圆环点(相机坐标系，三维)，与vector相比，list（链表）剔除离群点更有效率 d
    Eigen::Vector3d center_init; // 圆心初值
    Eigen::Vector3d direction_init; // 法向量初值
};

struct CircleBackendResult_t
{
    Eigen::Vector3d center;  // 圆心
    Eigen::Vector3d direction;  // 法向量
};

class CircleFrontend
{
private:
    const Eigen::Matrix3d inner_m_inv;  // 内参矩阵
    const double depth_min_thr;  // 深度滤波最小值
    const double depth_max_thr;  // 深度滤波最大值
    const int cnt;  // 采样点个数

public:
    CircleFrontend(const Eigen::Matrix3d& inner_m_, const double depth_min_thr_=0.1, const double depth_max_thr_=6, const int cnt_=150):
        inner_m_inv(inner_m_.inverse()), depth_min_thr(depth_min_thr_), depth_max_thr(depth_max_thr_), cnt(cnt_) { ; }
    
    CircleFrontendResult_t shape_frontend(cv::Mat& color_img, const cv::Mat& depth_img)const;
    CircleFrontendResult_t simple_depth_frontend(cv::Mat& color_img, const cv::Mat& depth_img)const;
};


class CircleBackend
{
private:
    const double R;
public:
    CircleBackend(const double R_): R(R_) { ; }
    CircleBackendResult_t ceres_backend(const CircleFrontendResult_t& input)const;
};