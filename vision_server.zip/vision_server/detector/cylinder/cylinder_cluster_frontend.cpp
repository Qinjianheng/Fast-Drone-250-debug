#include <iostream>

#include "detector.hpp"
#include "dbscan.hpp"

using namespace std;
using namespace cv;
using namespace Eigen;

void sample(const Mat& depth_img, const Matrix3d& inner_m_inv, const Matrix4d& R_b_c, const Matrix4d& R_w_b,
    vector<Vector2d>& sample_out, 
    const double depth_min_thr, const double depth_max_thr, const double height_min_thr, const double height_max_thr, const int cnt)
{
    double *wx = new double[depth_img.rows * depth_img.cols];
    double *wy = new double[depth_img.rows * depth_img.cols];
    int available_pixel = 0;
    for(int y = 0; y < depth_img.rows; y++){
        const float *depth_row = depth_img.ptr<float>(y);
        for(int x = 0; x < depth_img.cols; x++){
            const double depth = depth_row[x];
            if(isnan(depth) || fabs(depth) < depth_min_thr || fabs(depth) > depth_max_thr)
                continue;
            const Vector3d point_c_so3 = inner_m_inv * Vector3d(depth * x, depth * y, depth);
			const Vector4d point_c(point_c_so3.x(), point_c_so3.y(), point_c_so3.z(), 1);
            const Vector4d point_w = R_w_b * R_b_c * point_c;
            if(point_w.z() < height_min_thr || point_w.z() > height_max_thr)
                continue;
            wx[available_pixel] = point_w.x();
            wy[available_pixel++] = point_w.y();
        }
    }

    int step = available_pixel / cnt;
    step = step > 0 ? step : 1;

    for(int i = 0; i < available_pixel; i+=step)
		sample_out.push_back(Vector2d(wx[i], wy[i]));
    
    delete[] wx;
    delete[] wy;
}

CylinderFrontendResult_t CylinderFrontend::cluster_frontend(const Mat& depth_img, const Matrix4d& R_w_b) const
{
    if(depth_img.channels() != 1 || depth_img.depth() != CV_32FC1)
		throw "input not correct!";

    vector<Vector2d> sample_points;
    sample(depth_img, inner_m_inv, R_b_c, R_w_b, sample_points, depth_min_thr, depth_max_thr, height_min_thr, height_max_thr, cnt);
    if(sample_points.size() < 0.5 * cnt)
        throw "sample point too few!";

    //dbscan聚类
    vector<vector<Vector2d>> clusters;
    dbscan<Vector2d>(sample_points, dbscan_eps, dbscan_minpts, clusters, [](const Vector2d&v1, const Vector2d& v2) { return(v1 - v2).norm(); });

    vector<Vector2d> cylinders;

    const Vector2d p_w_2d = R_w_b.block<2, 1>(0, 3);
    for(const auto& cluster : clusters){
        Vector2d sum_direction(0, 0);
        for(const auto& point : cluster)
            sum_direction += point - p_w_2d;
        sum_direction /= cluster.size();
        cylinders.push_back(p_w_2d + sum_direction + sum_direction.normalized() * R);
    }

    CylinderFrontendResult_t res;
    res.clusters = std::move(clusters);
    res.cylinders = std::move(cylinders);
    return res;
}