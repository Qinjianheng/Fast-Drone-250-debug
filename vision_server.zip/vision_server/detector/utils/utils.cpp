#include "detector.hpp"

using namespace std;
using namespace cv;
using namespace Eigen;

double z_score_erase(list<Vector3d>& points, const double threshold)
{
	double sum = 0;
	for(auto point : points)
		sum += point.z();
	const double mean = sum / points.size();

	double squire_sum = 0;
	for(auto point : points)
		squire_sum += (point.z() - mean) * (point.z() - mean);
	const double std_dev = sqrt(squire_sum / (points.size() - 1));

	for(auto iter = points.begin(); iter != points.end(); iter++){
		const double z_score = fabs(iter->z() - mean) / std_dev;
		if(z_score > threshold){
			sum -= iter->z();
			points.erase(iter--);
		}
	}

	return sum / points.size();
}

Vector3d get_center_init(const list<Vector3d>& points, const double ave_depth)
{
    double sum_x = 0, sum_y = 0;
    for(auto p : points){
        sum_x += p.x();
        sum_y += p.y();
    }
    const double cx = sum_x / points.size();
    const double cy = sum_y / points.size();
    return Vector3d(cx, cy, ave_depth);
}

Vector3d get_direction_init(const list<Vector3d>& points, const double ave_depth)
{
	auto max_iter = points.begin(), min_iter = points.begin(), mid_iter = points.begin();

	for(auto iter = points.begin(); iter != points.end(); iter++){
		if(iter->z() > max_iter->z())
			max_iter = iter;
		if(iter->z() < min_iter->z())
			min_iter = iter;
		if(fabs(iter->z() - ave_depth) < fabs(mid_iter->z() - ave_depth))
			mid_iter = iter;
	}

	const auto v1 = *max_iter - *min_iter;
	const auto v2 = *min_iter - *mid_iter;
	const auto v3 = *mid_iter - *max_iter;

	Matrix<double, 3, 2> A;
	Vector3d B;
	A << v1.x(), v1.y(), v2.x(), v2.y(), v3.x(), v3.y();
	B << -v1.z(), -v2.z(), -v3.z();
	Matrix2d Phi_inv;
	bool invertible;
	(A.transpose() * A).computeInverseWithCheck(Phi_inv, invertible);
	if(!invertible)
		return Vector3d(0, 0, 1);
	else{
		const Vector2d res = (Phi_inv * A.transpose() * B).normalized();
		return Vector3d(res.x(), res.y(), 1).normalized();
	}
}
