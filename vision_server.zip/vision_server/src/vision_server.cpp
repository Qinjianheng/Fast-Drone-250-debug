#include <ros/ros.h>
#include <message_filters/subscriber.h>
#include <message_filters/time_synchronizer.h>

#include <cv_bridge/cv_bridge.h>

#include <sensor_msgs/Image.h>
#include <nav_msgs/Odometry.h>
#include <vision_server/circle.h>
#include <vision_server/cylinder.h>

#include <chrono>
#include "detector.hpp"
#include <opencv2/core/eigen.hpp>

using namespace std;
using namespace cv;
using namespace Eigen;

class VisionServer
{
private:
    ros::NodeHandle& nh;
    message_filters::Subscriber<sensor_msgs::Image> color_sub;
    message_filters::Subscriber<sensor_msgs::Image> depth_sub;
    message_filters::TimeSynchronizer<sensor_msgs::Image, sensor_msgs::Image> color_depth_sync;
    ros::Subscriber odom_sub;

    ros::ServiceServer cylinder_service;
    ros::ServiceServer circle_service;

    shared_ptr<CylinderFrontend> cylinder_frontend;
    shared_ptr<CylinderBackend> cylinder_backend;

    shared_ptr<CircleFrontend> circle_frontend;
    shared_ptr<CircleBackend> circle_backend;

    string circle_frontend_method;
    bool color_depth_init = false;
    bool odom_init = false;
    Matrix4d R_w_b;

    CylinderBackendResult_t cylinder_result;
    CircleBackendResult_t circle_result;

public:
    VisionServer(ros::NodeHandle& nh_, const FileStorage fs): 
        nh(nh_), color_sub(nh, (string)fs["color_topic"], 1), depth_sub(nh, (string)fs["depth_topic"], 1), color_depth_sync(color_sub, depth_sub, 10)
    {
        Mat cam_inner_cvmat, R_b_c_cvmat;
        fs["cam_inner"] >> cam_inner_cvmat; fs["body_T_cam"] >> R_b_c_cvmat;
        Eigen::Matrix3d cam_inner; Eigen::Matrix4d R_b_c;
        cv2eigen(cam_inner_cvmat, cam_inner); cv2eigen(R_b_c_cvmat, R_b_c);


        cylinder_frontend = make_shared<CylinderFrontend>(cam_inner, R_b_c, 
            (double)fs["cylinder_R"], (double)fs["depth_min_thr"], (double)fs["depth_max_thr"], 
            (double)fs["height_min_thr"], (double)fs["height_min_thr"], (double)fs["cylinder_sample_cnt"],
            (double)fs["cylinder_dbscan_eps"], (int)fs["cylinder_dbscan_minpts"]);
        cylinder_backend = make_shared<CylinderBackend>(Vector2d((double)fs["cylinder1_x"], (double)fs["cylinder1_y"]), 
                                                        Vector2d((double)fs["cylinder2_x"], (double)fs["cylinder2_y"]), 
                                                        Vector2d((double)fs["cylinder3_x"], (double)fs["cylinder3_y"]), 
                                                        Vector2d((double)fs["cylinder4_x"], (double)fs["cylinder4_y"]), 
                                                        (double)fs["cylinder_max_match_distance"]);
        circle_frontend = make_shared<CircleFrontend>(cam_inner, (double)fs["depth_min_thr"], (double)fs["depth_max_thr"], (double)fs["circle_sample_cnt"]);
        circle_backend = make_shared<CircleBackend>((double)fs["cylinder_R"]);

        R_w_b = Matrix4d::Identity();
        fs["circle_method"] >> circle_frontend_method;
        cylinder_service = nh.advertiseService((string)fs["cylinder_server_name"], &VisionServer::cylinder_srv_cb, this);
        circle_service = nh.advertiseService((string)fs["circle_server_name"], &VisionServer::circle_srv_cb, this);
        odom_sub = nh.subscribe((string)fs["odom_topic"], 1, &VisionServer::odom_cb, this);
        color_depth_sync.registerCallback(&VisionServer::color_depth_cb, this);

        ROS_INFO("waiting odom and img...");
        ros::Rate rate(100);
        while(ros::ok() && (!color_depth_init || !odom_init))
            rate.sleep();
        ROS_INFO("odom and img received!");
    }

private:
    void odom_cb(const nav_msgs::Odometry::ConstPtr& odom_msg)
    {
        if(!odom_init){
            odom_init = true;
            ROS_INFO("received odom!");
        }
        if(!odom_init || !color_depth_init)
            return;

        const auto& pose_msg = odom_msg->pose.pose.position;
        const auto& quat_msg = odom_msg->pose.pose.orientation;
        R_w_b.block<3, 3>(0, 0) = Eigen::Quaterniond(quat_msg.w, quat_msg.x, quat_msg.y, quat_msg.z).toRotationMatrix();
        R_w_b.block<3, 1>(0, 3) = Eigen::Vector3d(pose_msg.x, pose_msg.y, pose_msg.z);
        R_w_b.block<1, 4>(3, 0) << 0, 0, 0, 1;
    }

    void color_depth_cb(const sensor_msgs::Image::ConstPtr& color_msg, const sensor_msgs::Image::ConstPtr& depth_msg)
    {
        if(!color_depth_init){
            color_depth_init = true;
            ROS_INFO("received img!");
        }
        if(!odom_init || !color_depth_init)
            return;

        auto color_img = cv_bridge::toCvCopy(color_msg, "bgr8");
        auto depth_img = cv_bridge::toCvShare(depth_msg, depth_msg->encoding);
        try{
            auto cylinder_begin = chrono::high_resolution_clock::now();
            auto cylinder_frontend_result = cylinder_frontend->cluster_frontend(depth_img->image, R_w_b);
            auto cylinder_backend_result = cylinder_backend->filter_backend(cylinder_frontend_result);
            auto cylinder_end = chrono::high_resolution_clock::now();
            ROS_INFO("cylinder time cost: %.3fms", chrono::duration_cast<chrono::microseconds>(cylinder_end - cylinder_begin).count() * 1e-3);
            ROS_INFO("cylinder cluster num: %zu", cylinder_frontend_result.cylinders.size());
            for(int i = 0; i < 4; i++)
                ROS_INFO("cylinder %d: %.2f %.2f", i + 1, cylinder_backend_result.cylinders[i].x(), cylinder_backend_result.cylinders[i].y());
            cylinder_result = cylinder_backend_result;

            ROS_INFO("---");

            auto circle_begin = chrono::high_resolution_clock::now();
            auto circle_frontend_result = circle_frontend->shape_frontend(color_img->image, depth_img->image);
            auto circle_backend_result = circle_backend->ceres_backend(circle_frontend_result);
            auto circle_end = chrono::high_resolution_clock::now();
            ROS_INFO("circle time cost: %.3fms", chrono::duration_cast<chrono::microseconds>(circle_end - circle_begin).count() * 1e-3);
            ROS_INFO("circle center: %.2f %.2f %.2f", circle_backend_result.center.x(), circle_backend_result.center.y(), circle_backend_result.center.z());
            ROS_INFO("circle direction: %.2f %.2f %.2f", circle_backend_result.direction.x(), circle_backend_result.direction.y(), circle_backend_result.direction.z());
            circle_result = circle_backend_result;

            ROS_INFO("=========================");
        } catch(const char* e)
        {
            ROS_ERROR("%s", e);
        }
    }

    bool cylinder_srv_cb(vision_server::cylinder::Request &req, vision_server::cylinder::Response &res)
    {
        res.cylinder1_x = cylinder_result.cylinders[0].x(); res.cylinder1_y = cylinder_result.cylinders[0].y();
        res.cylinder2_x = cylinder_result.cylinders[1].x(); res.cylinder2_y = cylinder_result.cylinders[1].y();
        res.cylinder3_x = cylinder_result.cylinders[2].x(); res.cylinder3_y = cylinder_result.cylinders[2].y();
        res.cylinder4_x = cylinder_result.cylinders[3].x(); res.cylinder4_y = cylinder_result.cylinders[3].y();

        return true;
    }

    bool circle_srv_cb(vision_server::circle::Request &req, vision_server::circle::Response &res)
    {
        res.pos_x = circle_result.center.x(); res.pos_y = circle_result.center.y(); res.pos_z = circle_result.center.z();
        res.direction_x = circle_result.direction.x(); res.direction_y = circle_result.direction.y(); res.direction_z = circle_result.direction.z();

        return true;
    }
};
 
int main(int argc, char **argv)
{
    ros::init(argc, argv, "vision_server");
    ros::NodeHandle nh;
    FileStorage fs("/home/ccw/fast-drone-250-simulation/src/vision_server/config/config.yml", FileStorage::READ);
    VisionServer(nh, fs);
    ros::spin();
 
    return 0;
}