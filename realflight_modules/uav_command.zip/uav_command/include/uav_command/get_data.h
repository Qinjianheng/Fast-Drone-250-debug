#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <geometry_msgs/PoseStamped.h>
#include <quadrotor_msgs/TakeoffLand.h>
#include <nav_msgs/Odometry.h>
#include <eigen3/Eigen/Dense>

using namespace std;

namespace UAV_plan
{

    class odom_data
    {

    public:
        odom_data();
        ~odom_data();

        nav_msgs::Odometry odom;
        Eigen::Quaterniond odom_q;
        double yaw;

        void feed(const nav_msgs::Odometry::ConstPtr pMsg);

        void fromQuaternion2yaw(Eigen::Quaterniond q);
    };

    class tag2world_data
    {
    public:
        tag2world_data();
        ~tag2world_data();

        bool detection = 0; // 0: has not been deteted ;1: has not been deteted
        bool loop = 1;      // in whole loop of planner, there should be *** tag2world_data.loop = 1; ***
        ros::Duration duration = ros::Duration(0.05);

        tf::TransformListener listener;
        // get tf , tag bundle detections pose relative to world
        tf::StampedTransform transform_tag2world;
        geometry_msgs::PoseStamped tag2world;

        void waitfor_tag2world();
    };

}
