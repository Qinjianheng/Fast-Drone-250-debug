#include <uav_command/get_data.h>
#include <quadrotor_msgs/PositionCommand.h>

namespace UAV_plan
{
    class uav_command
    {
    private:
        // prameters
        double origin_x_;
        double origin_y_;

        double wall_x_0_;
        double wall_y_0_;

        double wall_x_1_;
        double wall_y_1_;

        double chunnel_x_;
        double chunnel_y_;

        double maze_x_0_;
        double maze_y_0_;

        double maze_x_1_;
        double maze_y_1_;

        double c0_x_;
        double c0_y_;
        double c0_z_;


        double land_x_;
        double land_y_;

        // task_flag
        //  1 -- takeoff
        //  2 -- pass through wall
        //  3 -- pass through chunnel
        //  4 -- pass through maze
        //  5 -- pass through  blue circle of 1.5m in diameter / c0
        //  6 -- c1
        //  7 -- c2
        //  8 -- c3
        //  9 -- land

    public:
        uav_command();
        ~uav_command();

        void init(ros::NodeHandle &nh);

        odom_data rc_odom;
        tag2world_data rc_tag2world;

        //  TYPE_WALL = 1  TYPE_CHANNEL = 2  TYPE_1.5M_CIRCLE = 3  TYPE_1M_CIRCLE = 4
        ros::ServiceClient object_client;

        ros::Publisher TakeoffLand_pub;
        ros::Publisher ego_pub;
        ros::Publisher px4_pub;

        double task_flag;
        bool land_flag;
        bool landing;
        bool debug;

        geometry_msgs::PoseStamped ego_setpoint;
        quadrotor_msgs::PositionCommand px4_setpoint;
        quadrotor_msgs::TakeoffLand Takeoff_land;

        bool px4_flag;
        bool ego_flag;
        bool next;

        double distance1;
        double distance2;
        double angle;
        double theta;

        // target
        double x;
        double y;
        double z;
        double yaw;

        void go2target(double x, double y, double z, double yaw);
        void ego(double x, double y, double z, double yaw, double dist);
        void px4(double x, double y, double z, double yaw, double dist);

        void land_planner();
        void task_planner();
        bool arrive1(double dst);
        bool arrive2(double dst);
    };
}
