#include <ros/ros.h>
#include <uav_command/uav_task.h>

/*FSM of this planner

     system_sart
          |
          |
          v
     Manual_Ctrl
          |
          |
          v
     Auto_takeoff
          |
          |
          v
      Auto_Hover------->Auto_Land
        |   ^           ^
        |   |          /
        v   |         /
      CMD_CTRL(task)-/

*/

using namespace std;

main(int argc, char **argv)
{
     ros::init(argc, argv, "uav_command");

     ros::NodeHandle n;
     UAV_plan::uav_command uav_cmd;
     uav_cmd.init(n);

     uav_cmd.ego_pub = n.advertise<geometry_msgs::PoseStamped>("/move_base_simple/goal", 10); // ego
     uav_cmd.TakeoffLand_pub = n.advertise<quadrotor_msgs::TakeoffLand>("/px4ctrl/takeoff_land", 10);
     uav_cmd.px4_pub = n.advertise<quadrotor_msgs::PositionCommand>("/position_cmd", 10); // px4

     ros::Subscriber odom_sub = n.subscribe<nav_msgs::Odometry>("/vins_fusion/imu_propagate",
                                                                10,
                                                                boost::bind(&UAV_plan::odom_data::feed, &uav_cmd.rc_odom, _1));

     // create Publishers and subscribers.
     // it takes time of register of publishers and subscribers. so, add a delay for 0.5s .
     ros::Duration(0.5).sleep(); // important

     ros::Rate loop_rate(10);

     // uav_cmd.px4_flag = true;

     while (ros::ok()) // 10 hz
     {
          ros::spinOnce();

          // uav_cmd.ego(3.0, 3.0, 1.0, 0);

          // uav_cmd.px4(3, 3, 1, 1.57);

          // uav_cmd.go2target(3, 3, 1, 1.57);

          uav_cmd.task_planner();

          loop_rate.sleep();
     }

     return 0;
}
