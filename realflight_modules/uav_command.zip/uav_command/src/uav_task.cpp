
#include <uav_command/uav_task.h>

namespace UAV_plan
{

    uav_command::uav_command()
    {
        land_flag = 0;
        landing = 0;
        task_flag = 1;
        Takeoff_land.takeoff_land_cmd = 1; // takeoff:1   land:2
        ego_setpoint.header.frame_id = "world";
        debug = 1;

        yaw = 0;

        // init px4ctrl
        px4_setpoint.header.stamp = ros::Time::now();
        px4_setpoint.position.x = 0;
        px4_setpoint.position.y = 0;
        px4_setpoint.position.z = 2.5;

        px4_setpoint.velocity.x = 0;
        px4_setpoint.velocity.y = 0;
        px4_setpoint.velocity.z = 0;

        px4_setpoint.acceleration.x = 0;
        px4_setpoint.acceleration.y = 0;
        px4_setpoint.acceleration.z = 0;

        px4_setpoint.jerk.x = 0;
        px4_setpoint.jerk.y = 0;
        px4_setpoint.jerk.z = 0;

        px4_setpoint.yaw = 0;
        px4_setpoint.yaw_dot = 0;

        px4_flag = true;

        // init ego_planner
        ego_setpoint.pose.position.x = 0;
        ego_setpoint.pose.position.y = 0;
        ego_setpoint.pose.position.z = 2.5;
        theta = 0;
        ego_setpoint.pose.orientation.w = cos(theta / 2.0);
        ego_setpoint.pose.orientation.x = 0;
        ego_setpoint.pose.orientation.y = 0;
        ego_setpoint.pose.orientation.z = sin(theta / 2.0);

        ego_flag = true;

        next = false;
    }

    uav_command::~uav_command()
    {
    }

    void uav_command::init(ros::NodeHandle &nh)
    {
        // these parameters are in custom world frame
        //  x -- forward
        //  y -- right
        //  original point of world frame is at the bottom left
        nh.param("/uav_command/task/origin_x", origin_x_, 0.65);
        nh.param("/uav_command/task/origin_y", origin_y_, 5.77);

        nh.param("/uav_command/task/wall_x_0", wall_x_0_, 6.0);
        nh.param("/uav_command/task/wall_y_0", wall_y_0_, 6.0);

        nh.param("/uav_command/task/wall_x_1", wall_x_1_, 6.0);
        nh.param("/uav_command/task/wall_y_1", wall_y_1_, 6.0);

        nh.param("/uav_command/task/chunnel_x", chunnel_x_, 15.0);
        nh.param("/uav_command/task/chunnel_y", chunnel_y_, 7.0);

        nh.param("/uav_command/task/maze_x_0", maze_x_0_, 24.0);
        nh.param("/uav_command/task/maze_y_0", maze_y_0_, 9.0);

        nh.param("/uav_command/task/maze_x_1", maze_x_1_, 24.0);
        nh.param("/uav_command/task/maze_y_1", maze_y_1_, 9.0);

        nh.param("/uav_command/task/c0_x", c0_x_, 25.0);
        nh.param("/uav_command/task/c0_y", c0_y_, 25.0);
        nh.param("/uav_command/task/c0_z", c0_z_, 2.25);

        nh.param("/uav_command/task/land_x", land_x_, 1.0);
        nh.param("/uav_command/task/land_y", land_y_, 26.0);


       // object_client = nh.serviceClient<object_all::object>("/obj_position");
        //srv.request.type = 1;

        // object_client.call(srv);
        // A_x_ = srv.response.Point.x;
        // B_y_ = srv.response.Point.y;
        // C_z_ = srv.response.Point.z;
    }

    // Does ego_planner arrive its target?
    bool uav_command::arrive1(double dst)
    {
        distance1 = pow(rc_odom.odom.pose.pose.position.x - ego_setpoint.pose.position.x, 2) + pow(rc_odom.odom.pose.pose.position.y - ego_setpoint.pose.position.y, 2);
        distance1 = sqrt(distance1);
        // ROS_INFO("distance1: %.2f", distance1);

        if (distance1 < dst)
            return true;
        else
            return false;
    }

    // Does px4ctrl  arrive its target?
    bool uav_command::arrive2(double dst)
    {

        distance2 = pow(rc_odom.odom.pose.pose.position.x - px4_setpoint.position.x, 2) + pow(rc_odom.odom.pose.pose.position.y - px4_setpoint.position.y, 2);

        angle = abs(px4_setpoint.yaw - rc_odom.yaw);

        distance2 = sqrt(distance2);

        // ROS_INFO("distance2: %.2f", distance2);
        //  ROS_INFO("odom_yaw: %.2f", rc_odom.yaw);
        // ROS_INFO("angle: %.2f", angle);

        // ROS_INFO("yaw_setpoint:%.2f", px4_setpoint.yaw);

        if (px4_setpoint.yaw < 3.1 && px4_setpoint.yaw > -3.1)
        {
            // ROS_INFO("0 0 0");
            if (distance2 < dst && angle < 0.1)
                return true;
            else
                return false;
        }

        if (3.1 < px4_setpoint.yaw || px4_setpoint.yaw < -3.1) // 0 --- M_PI  0 ---  -M_PI
        {
            // ROS_INFO("M_PI");
            if ((distance2 < dst && angle < 0.1) || (distance2 < dst && angle > 6.18))
                return true;
            else
                return false;
        }
    }

    //启用前
    // ego_flag = true;
    // px4_flag = true;
    // next = false;

    void uav_command::go2target(double x, double y, double z, double yaw)
    {
        ego_setpoint.header.stamp = ros::Time::now();
        ego_setpoint.pose.position.x = x;
        ego_setpoint.pose.position.y = y;
        ego_setpoint.pose.position.z = z;
        ego_setpoint.pose.orientation.w = cos(yaw / 2.0);
        ego_setpoint.pose.orientation.x = 0;
        ego_setpoint.pose.orientation.y = 0;
        ego_setpoint.pose.orientation.z = sin(yaw / 2.0);

        px4_setpoint.header.stamp = ros::Time::now();
        px4_setpoint.position.x = x;
        px4_setpoint.position.y = y;
        px4_setpoint.position.z = z;
        px4_setpoint.yaw = yaw;

        //先用ego_planner 引导到目标位置
        //再调用px4ctrl旋转到合适的角度

        if (ego_flag)
        {
            ego_pub.publish(ego_setpoint);
        }
        ego_flag = false;

        if (arrive1(0.3) && px4_flag == true)
        {
            px4_flag = false;
            ROS_INFO("ego arrives at target!!!");
        }

        if (!px4_flag)
        {
            px4_pub.publish(px4_setpoint);

            if (arrive2(0.1) && next == false)
            {
                px4_flag = true;
                next = true;

                ros::Duration(1).sleep();

                ROS_INFO("px4 arrives at target!!!");
            }
        }
    }

    //启用前
    // ego_flag = ture;
    // next = false;

    void uav_command::ego(double x, double y, double z, double yaw, double dist)
    {
        ego_setpoint.header.stamp = ros::Time::now();
        ego_setpoint.pose.position.x = x;
        ego_setpoint.pose.position.y = y;
        ego_setpoint.pose.position.z = z;
        ego_setpoint.pose.orientation.w = cos(yaw / 2.0);
        ego_setpoint.pose.orientation.x = 0;
        ego_setpoint.pose.orientation.y = 0;
        ego_setpoint.pose.orientation.z = sin(yaw / 2.0);

        if (ego_flag)
        {
            ego_pub.publish(ego_setpoint);
        }
        ego_flag = false;

        if (arrive1(dist) && next == false)
        {
            ROS_INFO("ego arrives at target!!!");
            next = true;
        }
    }

    //启用px4_flag = true;
    // next = false;
    void uav_command::px4(double x, double y, double z, double yaw, double dist)
    {
        px4_setpoint.header.stamp = ros::Time::now();
        px4_setpoint.position.x = x;
        px4_setpoint.position.y = y;
        px4_setpoint.position.z = z;
        px4_setpoint.yaw = yaw;

        if (px4_flag)
        {
            px4_pub.publish(px4_setpoint);
        }

        if (arrive2(dist) && next == false)
        {
            next = true;
            px4_flag = false;
            ROS_INFO("px4 arrives at target!!!");
        }
    }

    void uav_command::land_planner()
    {

        rc_tag2world.waitfor_tag2world();

        rc_tag2world.loop = 1;

        if (rc_tag2world.detection == 1) // start langing process
        {
            if (!land_flag)
            {
                x = rc_tag2world.tag2world.pose.position.x;
                y = rc_tag2world.tag2world.pose.position.y;
                z = 1.5;
                yaw = rc_odom.yaw;

                px4(x, y, z, yaw, 0.1);

                if (debug)
                {
                    ROS_INFO("flying to land_tag: x:%0.1f  y:%0.1f  z:%0.1f", x, y, z);
                }

                debug = 0;

                if (next == true)
                {
                    land_flag = 1;
                    ROS_ERROR("lang_flag = 1");
                }
            }

            if (land_flag == 1 && !landing)
            {
                Takeoff_land.takeoff_land_cmd = 2;
                ROS_INFO("landing!!!");

                ros::Duration(1).sleep();
                TakeoffLand_pub.publish(Takeoff_land);
                landing = 1;

                ROS_ERROR("landing!!!");
            }
        }
    }

    void uav_command::task_planner()
    {
        // take_off
        if (task_flag == 1)
        {
            Takeoff_land.takeoff_land_cmd = 1;
            TakeoffLand_pub.publish(Takeoff_land);
            task_flag = 2;
            ROS_INFO("takeoff!!!");
        }

        // wall
        if (task_flag >= 2 && task_flag < 3)
        {

            if (task_flag == 2)
            {
                if (ego_flag == true)
                {
    
                    x = wall_x_0_ ;
                    y = wall_y_0_ ;
                    z = 1.5;
                    yaw = M_PI / 2;

                    ROS_INFO("wall_0 !!! x:%.2f y:%.2f z:%.2f", x, y, z);
                }

                ego(x, y, z, yaw, 0.5);

                if (next == true)
                {
                    ego_flag = true;
                    px4_flag = true;

                    task_flag = 2.2;
                    next = false;
                }
            }

            if (task_flag == 2.2)
            {

                x = wall_x_1_ ;
                y = wall_y_1_ ;
                z = 1.5;
                yaw = 0;

                if (ego_flag == true)
                    ROS_INFO("wall_1 !!! x:%.2f y:%.2f z:%.2f", x, y, z);

                ego(x, y, z, yaw, 0.5);

                if (next == true)
                {
                    ego_flag = true;
                    px4_flag = true;

                    task_flag = 3;
                    next = false;
                }
            }
        }

        // chunnel
        if (task_flag >= 3 && task_flag < 4)
        {
            if (task_flag == 3)
            {

                x = chunnel_x_ ; //-3
                y = chunnel_y_ ; // 2.5
                z = 1.75;
                yaw = -M_PI / 4;

                if (ego_flag == true)
                    ROS_INFO("chunnel_0_find !!! x:%.2f y:%.2f z:%.2f angle:%.2f", x, y, z, yaw);

                go2target(x, y, z, yaw);

                if (next == true)
                {
                    ego_flag = true;
                    px4_flag = true;

                    task_flag = 3.1;
                    next = false;
                }
            }

            // if (task_flag == 3.1)
            // {
            //     if (ego_flag == true)
            //     {
            //         // srv.request.type = 2;
            //         ROS_INFO("request for target");
            //         // object_client.call(srv);
            //         ROS_INFO("get response!");

            //         // chunnel_x_ = srv.response.Point.x;
            //         // chunnel_y_ = srv.response.Point.y;

            //         x = chunnel_x_-0.66;
            //         y = chunnel_y_;
            //         z = 1.75;
            //         yaw = 0;

            //         ROS_INFO("chunnel_0 !!! x:%.2f y:%.2f z:%.2f", x, y, z);
            //     }

            //     go2target(x, y, z, yaw);

            //     if (next == true)
            //     {
            //         ego_flag = true;
            //         px4_flag = true;

            //         task_flag = 3.2;
            //         next = false;
            //     }
            // }

            if (task_flag == 3.2)
            {
                if (ego_flag == true)
                {
                    x = chunnel_x_ + 2;
                    y = chunnel_y_;
                    z = 1.75;
                    yaw = 0;

                    ROS_INFO("chunnel_1 !!! x:%.2f y:%.2f z:%.2f", x, y, z);

                    ego_flag = false;
                }

                px4(x, y, z, yaw, 0.35);

                if (next == true)
                {
                    ego_flag = true;
                    px4_flag = true;

                    task_flag = 3.3;
                    next = false;
                }
            }

            if (task_flag == 3.3)
            {
                x = maze_x_0_ ;
                y = maze_y_0_ ;
                z = 1.5;
                yaw = -M_PI / 2;

                if (ego_flag == true)
                    ROS_INFO("maze_0 !!! x:%.2f y:%.2f z:%.2f", x, y, z);

                ego(x, y, z, yaw, 0.5);

                if (next == true)
                {
                    ego_flag = true;
                    px4_flag = true;

                    task_flag = 4;
                    next = false;
                }
            }
        }

        // maze
        if (task_flag >= 4 && task_flag < 5)
        {
            if (task_flag == 4)
            {

                x = maze_x_1_;
                y = maze_y_1_;
                z = 1.5;
                yaw = M_PI;

                if (ego_flag == true)
                    ROS_INFO("maze_1 !!! x:%.2f y:%.2f z:%.2f", x, y, z);

                ego(x, y, z, yaw, 0.5);

                if (next == true)
                {
                    ego_flag = true;
                    px4_flag = true;

                    task_flag = 5;
                    next = false;
                }
            }
        }

        // circle_0

        if (task_flag >= 5 && task_flag < 6)
        {
            if (task_flag == 5)
            {

                x = c0_x_ + 3.5;
                y = c0_y_;
                z = c0_z_;
                yaw = M_PI;

                if (ego_flag == true)
                    ROS_INFO("circle_0_find !!! x:%.2f y:%.2f z:%.2f", x, y, z);

                go2target(x, y, z, yaw);

                if (next == true)
                {
                    ego_flag = true;
                    px4_flag = true;

                    task_flag = 5.1;
                    next = false;
                }
            }

            // if (task_flag == 5.1)
            // {
            //     if (ego_flag == true)
            //     {
            //         srv.request.type = 3;
            //         ROS_INFO("request for target");
            //         object_client.call(srv);
            //         ROS_INFO("get response!");

            //         c0_x_ = srv.response.Point.x;
            //         c0_y_ = srv.response.Point.y;
            //         c0_z_ = srv.response.Point.z;

            //         x = c0_x_ + 1;
            //         y = c0_y_;
            //         z = c0_z_;
            //         yaw = M_PI;

            //         ego_flag = false;

            //         ROS_INFO("circle_0_0 !!! x:%.2f y:%.2f z:%.2f", x, y, z);
            //     }

            //     px4(x, y, z, yaw, 0.4);

            //     if (next == true)
            //     {
            //         ego_flag = true;
            //         px4_flag = true;

            //         task_flag = 5.2;
            //         next = false;
            //     }
            // }

            if (task_flag == 5.2)
            {
                if (ego_flag == true)
                {
                    x = c0_x_ - 1;
                    y = c0_y_;
                    z = c0_z_;
                    yaw = M_PI;
                    ROS_INFO("circle_0_1 !!! x:%.2f y:%.2f z:%.2f", x, y, z);
                    ego_flag = false;
                }

                px4(x, y, z, yaw, 0.4);

                if (next == true)
                {
                    ego_flag = true;
                    px4_flag = true;

                    task_flag = 9;
                    next = false;
                }
            }
        }

        if (task_flag >= 9 && task_flag < 10)
        {
            if (task_flag == 9)
            {
                x = land_x_;
                y = land_y_;
                z = 1.5;
                yaw = M_PI;

                if (ego_flag == true)
                    ROS_INFO("go to apriltag !!! x:%.2f y:%.2f z:%.2f", x, y, z);

                ego(x, y, z, yaw, 0.3);

                if (next == true)
                {
                    ego_flag = true;
                    px4_flag = true;

                    task_flag = 9.1;
                    next = false;
                }
            }

            if (task_flag == 9.1)
            {
                land_planner();
            }
        }
    }

}